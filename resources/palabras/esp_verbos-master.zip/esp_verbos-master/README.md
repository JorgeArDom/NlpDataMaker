# Verbos en español y sus conjugaciones
>Verbos en español con sus conjugaciones, recopilados de varias páginas web, en formato PostgreSQL y json 

Para armar esta base de datos de conjugaciones de verbos partí de varias listas de verbos en Internet como [helloworld.com.es](http://www.helloworld.com.es/english/quick%20reference/verbs/SpanishVerbList.htm), la mayor tomada del proyecto SpanishJS de @damiancipolat con más de 15 mil palabras, luego probé cada palabra contra sitios como [spanishdict](http://www.spanishdict.com/)  de donde tomé las conjugaciones haciendo webscraping

Echa un ojo a la [guía para contribuir](CONTRIBUTING.md) antes de reportar algún error.

LICENCIA
------------
Comparto estos datos recopilados bajo una licencia [CC by-sa 4.0](https://creativecommons.org/licenses/by-sa/4.0/)


¿Falta agún verbo? ¿Quieres contribuir? 
------------
Mira [cómo contribuir](CONTRIBUTING.md).


