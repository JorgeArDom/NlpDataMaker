# ¡Contribuye!

Este proyecto se adhiere al [código de conducta de código abierto][code-of-conduct]. Al participar, se espera que actúes en base a este código de honor


## Envia un Pull Request

1. Fork it.
2. Create a branch (`git checkout -b mis_verbos`)
3. Commit your changes (`git commit -am "agregados nuevos verbos"`)
4. Push to the branch (`git push origin mis_verbos`)
5. Open a [Pull Request][1]

[1]: http://github.com/asosab/esp_verbos/pulls
[code-of-conduct]: http://todogroup.org/opencodeofconduct/#GitHub%20Markup/opensource@github.com
